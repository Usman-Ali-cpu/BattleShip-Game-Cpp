public class main {
    public static void main(String[] args) {
        Employee emp1 = new Employee();
        Employee emp2 = new Employee("John", 0.9, 50);
        emp1.print();
        emp2.print();
    }

}