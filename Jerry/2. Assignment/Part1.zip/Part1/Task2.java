import java.util.Scanner;


public class Task2 {

    public static void main(String [] args){
        Scanner input = new Scanner(System.in);

        System.out.println("Please Enter 5 values to place in array (Seperated by Enter) : ");

        int Array1[] = new int[5];
        for(int i=0; i< 5; i++){
            Array1[i] = input.nextInt();
        }


        int Array2[] = new int[10];
        for(int i=0; i< 5; i++){
            Array2[i] = Array1[i];
        }

        System.out.println("Please Enter 3 more values to place in array (Seperated by Enter) : ");
        for(int i=5; i< 8; i++){
            Array2[i] = input.nextInt();
        }
        System.out.println("Arrays you have created ");
        printArray(Array1, 5);
        printArray(Array2, 10);


    }
    public static void printArray(int []arr, int n){
        for(int i=0; i< n; i++){
            System.out.print(arr[i] + ", ");
        }
        System.out.println();

    }

    
}
