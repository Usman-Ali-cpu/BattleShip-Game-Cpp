import java.util.Scanner;


public class Task3 {
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        int n = 0;

        do {    
            System.out.print("How many terms are in your Quiz (5- 10) : ");
            n = input.nextInt();
        } while (n < 5 || n > 10);
        input.nextLine();

        String[][] arr = new String[n][2];

        for(int i=0; i< n ; i++){
            System.out.print("Please Enter a term : ");
            arr[i][0] = input.nextLine();
            System.out.print("Please Enter that term's defination : ");
            arr[i][1] = input.nextLine();
        }
        printData(arr);
    }

    public static void printData(String [][] arr){
        System.out.print("items for your Quiz are:  [");
        for(int i=0; i< arr.length; i++){
            System.out.print("[" + arr[i][0] + ", " + arr[i][1] + "],  ");
        }
        System.out.println("]");

    }

    
}
