import java.util.Scanner;
import java.lang.Math;

public class Task1{
    public static void main(String args[]){
        Scanner input = new Scanner(System.in);
        int n;

        System.out.print("How many values will you enter : ");
        n = input.nextInt();

        int Array[] = new int[n];
        for(int i=0; i< n; i++){
            System.out.print("Please Enter value to place in array : ");
            Array[i] = input.nextInt();
        }
        System.out.println("Average of array elements is : " + getAvg(Array, n));
        System.out.println("Standard deviation of array elements is : " + getSD(Array, n, getAvg(Array, n)));

    }

    public static double getAvg(int []Array, int n){
        int sum =0;
        for(int i=0; i< n; i++){
            sum += Array[i];
        }
        double avr = sum/n;
        return avr;
    }
    public static double getSD(int []array, int n, double avr){
        double standardDeviation =0; 
        for(int num: array) {
            standardDeviation += Math.pow(num - avr, 2);
        }

        return Math.sqrt(standardDeviation/n);
    }


}