import java.util.Scanner;
public class Question2 {

    public static void main(String [] agrs){
        Scanner input = new Scanner(System.in);
        int hours;
        System.out.print("Enter number of hours worked in a week: ");
        hours = input.nextInt();
        while(hours > 60){
            System.out.print("You can not work more than 60 hours in a week ");
            System.out.print("Enter number of hours worked in a week: ");
            hours = input.nextInt();
        }while(hours > 60);
        double wages = 0.0;

        if(hours <= 40){
            wages = hours * 30;
        }
        if (hours> 40){
            wages = 40 * 30 + (hours-40) * (30* 1.5);
        }
        double socialSecurity = 0.06 * wages;
        double tax = 0.07 * wages;
        double unionDues = 0.03 * wages;

        System.out.println("Total Wages = " + wages);
        System.out.println("Social Security = " + String.format("%.2f", socialSecurity));
        System.out.println("Taxes = " +String.format("%.2f", tax));
        System.out.println("Union Dues = " + String.format("%.2f", unionDues));
    }
}
