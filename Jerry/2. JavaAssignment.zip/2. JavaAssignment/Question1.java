import java.util.Scanner;

public class Question1{
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Profit of a Company : ");
        int profit = input.nextInt();
        String catagory = "";
        if(profit <= 5000){
            catagory = "small";
        }
        else if(profit > 5000 && profit <= 10000){
            catagory = "medium";
        }
        else {
            catagory = "large";
        }
        float sumTax = computeTaxes(profit, catagory);
        float refuseTax = (float) (0.02 * sumTax);
        float totalTax = sumTax + refuseTax;
        System.out.println("Catagory : " + catagory);
        System.out.println("Tax Before Refuse : " +  String.format("%.2f", sumTax));
        System.out.println("Refuse Tax: " + String.format("%.2f", refuseTax));
        System.out.println("Total Tax: " +  String.format("%.2f", totalTax));
    }

    public static float computeTaxes(int GHs, String catagory){
        float tax = 0;
        if(catagory.equals("small")){
            if(GHs <= 3000){
                tax = (float) (0.03 * GHs);
            }
            else{
                tax = (float) (0.05 * GHs);
            }
        }
        else if(catagory.equals("medium")){
            if(GHs <= 8000){
                tax = (float) (0.05 * GHs);
            }
            else{
                tax = (float) (0.08 * GHs);
            }
            
        }
        else if(catagory.equals("large")){
            if(GHs <= 1500){
                tax = (float) (0.085 * GHs);
            }
            else{
                tax = (float) (0.12 * GHs);
            }
        }
        return tax;

    }
}