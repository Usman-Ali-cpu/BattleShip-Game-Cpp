import java.util.Scanner;

public class Question4 {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter Name of country : ");
        String name = input.nextLine();
        System.out.print("Enter your Age : ");
        int age = input.nextInt();
        isEligible(name, age);

    }
    public static void isEligible(String name, int age){
        if(name.toLowerCase().equals("ghana") && age>=18){
            System.out.println("Your Are Eligible for Vote");
        }
        else{
            System.out.println("You are not Eligible for vote");
        }
    }
}
