#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

vector<string> reader(const string & fileName) {
		ifstream file; // to read file 
		file.open(fileName); // open the file 
		string data;
		vector<string> result;  // vector to string to place data after reading 
		while (file.is_open() && !file.eof()) {  // read while file end and file is open 
			getline(file, data);  // get each line and store in string 
			if (!data.empty()) {  
				result.push_back(data);  // push string in vector 
			}
		}
		if(file.is_open())
			file.close();  // close the file 
		return result;  // return vector 
}

void writer(const string & fileName, const vector<string>& data) {
	ofstream file;   // to write into file 
	file.open(fileName,ios::in | ios::out);  // open the file to write 
	if (file.is_open()) {
		for (string s : data) {  // take string in each loop while data has any string 
			file << s + "\n";  // write into file
		}
		file.close();  // close the file 
	}
}

int studentGradeA(vector<string> data){
    int students = 0; // to store count of students 
    for(string s: data){  // iterate through each string in vector 
        char a = s[s.length() - 1]; //get last charactor of string 
        if(a== 'A'){  // check if it has A grade 
            students++; // increment student count 
        }
    }
    return students; // return students 
}
double getTotalMarks(vector<string> data, string student){
    string roll,marks; // to store roll number and marks 
    double re;
    for(string s: data){   // take string in each loop while data has any string 
        int index = s.find_first_of(','); // find index where firt , exist 
        roll = s.substr(0, index); // subtring from 0 to index, 
        if(student == roll){ // check if roll number match 
            s.erase(0, index + 1);  // erase substring 
            index = s.find_first_of(','); // get index of fist , 
            marks = s.substr(0, index);  // get marks string 
            return stod(marks); // covert and return 
        }
    }
    return 0; // else return 0;
}
int Gracing(vector<string> data){
    vector<string> newVector; // array of string vector 
    int count = 0; // for counter 
    char grade;
    int index;
    double marks;
    string full, roll;
    for(string s: data){ // iterrate through each string in an array 
        grade = s[s.length() - 1]; // get last char of string 
        if(grade == 'F'){ // check if grade is F
            index = s.find_first_of(','); // index of first , 
            marks = stod(s.substr(index+1,4)); // sub string 
            if(marks<50){ // check if marks are less than 50 
                count++;
                while(marks<50){ // increment marks while it will be 50 
                    marks++;
                }
                index = s.find_first_of(',');
                roll = s.substr(0, index);
                full = roll + "," + to_string(marks) + "," + "D"; // made astring 
                newVector.push_back(full); // store string in vector 
            }
        }
    }
    writer("fails.txt", newVector);
    return count;
}

void update(vector<string> data){
    vector<string> newVector; // array of string vector 
    char grade;
    int index;
    double marks;
    string full, roll;
    for(string s: data){  // iterrate through each string in an array 
        grade = s[s.length() - 1]; //  get last char of string 
        if(grade == 'F'){  // check if grade is F
            index = s.find_first_of(',');
            marks = stod(s.substr(index+1,4));
            if(marks<50){ // check if marks are less than 50 
                while(marks<50){   // increment marks while it will be 50 
                    marks++;
                }
                index = s.find_first_of(',');
                roll = s.substr(0, index);
                full = roll + "," + to_string(marks) + "," + "D";
                newVector.push_back(full); // insert string at the end of vector array 
            }
        }else {
            newVector.push_back(full); // if not f grade then push without any change 
        }
    }
    writer("students.txt", newVector); // write into this files 
}

int main(){
    vector<string> data = reader("student.txt"); // read data from file 
    int c = -1;
    while(c!= 5)
    {
        cout << "1. Check how many Students has A grade " << endl;
        cout << "2. Check marks of a Student " << endl;
        cout << "3. Gracing the fail Students " << endl;
        cout << "4. Update orignal data after gracing " << endl;
        cout << "5. Quit " << endl;
        cout << "Enter choice : ";
        cin >> c;
        switch (c)
        {
        case 1:
            cout<< studentGradeA(data)<< endl; //  number of students with A grade 
            break;
        case 2:
        {
            string r;
            cout << "Enter roll number of Student : ";
            cin >> r;
            cout << getTotalMarks(data, r); // get total marks of passing roll number  
            break;
        }
        case 3:
            cout<<"Gracing Students are : " << Gracing(data)<< endl; // gracing data who are going to fail in subjects  
            break;
        case 4:
            update(data);  // update file with gracing data who are going to fail in subjects 
            break;
        case 5:
            cout << "Quiting " << endl;  // terminate the program 
            exit(0);
            break;
        default:
            cout << "Invalid entry  " << endl; // non choice 
            break;
        }
    }
    return 0;
}