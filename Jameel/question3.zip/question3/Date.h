#ifndef COSC1076_A3_DATE_H
#define COSC1076_A3_DATE_H

#include <iostream>
using namespace std;

class Date{
public:    
    
    // Constructors/DeConstructors
    Date();

    //dayNumber is the number of days since 1/3/0000 
    Date(unsigned long dayNumber);
    Date(const Date& other);
    Date(Date&& other);
    ~Date();

    //Contract: Year, Month, Day should be valid
    //          Year should be a positive number, 
    //          month should be a number in range [1,12], 
    //          date should be a numbers in range [1,31] and valid. 
    Date(unsigned int year, unsigned int month, unsigned int day);

    
    //Getters and setters
    unsigned int getDay();
    unsigned int getMonth();
    unsigned int getYear();
    unsigned long getDayNumber() const;

    void setDate(unsigned long dayNumber);

    //Contract: Year, Month, Day should be valid
    //          Year should be a positive number, 
    //          month should be a number in range [1,12], 
    //          date should be a numbers in range [1,31] and valid. 
    void setDate(unsigned int year, unsigned int month, unsigned int day);

    int  operator-(Date & d){
        this->day -= d.day;
        this->month -= d.month;
        this->year -= d.year;
        return this->getDayNumber();
    }
    void operator+=(int){
        int n = this->getDayNumber();
        this->setDate(n);
    }
    void operator++(){
        int n = this->getDayNumber();
        this->setDate(++n);
    }
    void operator--(){
        int n = this->getDayNumber();
        this->setDate(--n);
    }
    unsigned int & operator[](char c){
        if(c == 'd') {
            return day;
        }
        else if(c == 'm') {
            return month;
        }
        else {
            return year;
        }
        return day;
    }

    Date operator-(int i){
        int n = this->getDayNumber();
        n = n - i;
        this->setDate(n);
        return *this;
    }
    bool operator==(Date &d1){
        int n = this->getDayNumber();
        int m = d1.getDayNumber();
        if(n == m){
            return true;
        }
        return false;
    }
    bool operator<(Date &d1){
        int n = this->getDayNumber();
        int m = d1.getDayNumber();
        if(n < m){
            return true;
        }
        return false;
    }

    /*                                           */
    /* YOU MAY ADD YOUR MODIFICATIONS HERE       */
    /*                                           */

    friend ostream &operator<<(ostream &out, Date &p);

private:
    /*                                           */
    /* DO NOT MOFIFY ANY CODE IN THIS SECTION    */
    /*                                           */
    unsigned int year;
    unsigned int month;
    unsigned int day;
};





ostream& operator<<(ostream& out, Date& p)
{
    out << p.day << "/" << p.getMonth() << "/" << p.getYear() << std::endl;
    return out;
}
#endif //COSC1076_A3_DATE_H

