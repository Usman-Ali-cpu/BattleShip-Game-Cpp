#include <iostream>
#include "Date.cpp"
using namespace std;


int main(){
    

    Date d;
    d.printDate();


    return 0;
}