#include <stdio.h>

int findElement(int array[], int size, int keyToBeSearched)
{
    int i;
    // Finding & returning the position of the element
    for (i = 0; i < size; i++)
        if (array[i] == keyToBeSearched)
            return i;
    return -1;
}

//Function to insert an element in an array.
//arr[] = array, elements = number of elements present in the array
//keyToBeInserted = element to be inserted in the array
// size of the array
int insertElement(int arr[], int elements, int keyToBeInserted, int size)
{
    // Check if the capacity of the array is already full
    if (elements >= size)
        return elements;
    //If not then the element is inserted at the last index
    //and the new array size is returned
    arr[elements] = keyToBeInserted;
    return (elements + 1);
}

// Function to delete an element
// where array[] is the array from which element needs to be deleted
// size is the size of the array
// keyToBeDeleted is the element to be deleted from the array
int deleteElement(int array[], int size, int keyToBeDeleted)
{
    // Calling findElement function to get the position of the element which needs to be deleted
    int pos = findElement(array, size, keyToBeDeleted);
    // If element is not found then it prints Element not found
    if (pos == -1)
    {
        printf("Element not found");
        return size;
    }
    // Otherwise it deletes the element & moves rest of the element by one position
    int i;
    for (i = pos; i < size - 1; i++)
        array[i] = array[i + 1];
    return size - 1;
}

void displayArray(int array[], int size)
{
    if (size <= 0)
    {
        printf("Element not found");
        return;
    }
    // Otherwise it deletes the element & moves rest of the element by one position
    int i;
    printf("{");
    for (i = 0; i < size; i++)
    {
        printf("%d,", array[i]);
    }
    printf("}\n");
}

int main()
{
    int array[20] = {0};
    int size = sizeof(array) / sizeof(array[0]);
    int eleCount = 0;

    int num3, num2, num;

    int run = 0;
    int choice;

    while (choice != 0)
    {
        printf("\nEnter 0. Quit\n");
        printf("Enter 1. Add Number\n");
        printf("Enter 2. Delete Number\n");
        printf("Enter 3. Search Number\n");
        printf("Enter 4. Display Numbers\n");
        printf("Enter Choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 0:
            printf("Quiting ");
            return 0;
            break;
        case 1:
            printf("ADDING NUMBER\n");
            printf("Enter a number : ");
            scanf("%d", &num);
            eleCount = insertElement(array, eleCount, num, size);

            break;
        case 2:
            printf("DELETING NUMBER\n");
            printf("Enter a number : ");
            scanf("%d", &num2);
            eleCount = deleteElement(array, eleCount, num2);

            break;
        case 3:
            printf("SEARCHING NUMBER\n");
            printf("Enter a number : ");
            scanf("%d", &num3);
            int index = findElement(array, size, num3);
            printf("Index of %d is : %d\n", num3, index);
            break;
        case 4:
            printf("DISPLAY NUMBERS\n");
            displayArray(array, eleCount);
            break;

        default:
            printf("Invalid Choice \n");
            break;
        }
    }

    return 0;
}