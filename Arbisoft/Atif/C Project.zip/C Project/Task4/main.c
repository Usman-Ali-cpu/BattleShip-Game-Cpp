#include <stdio.h>
#include <stdbool.h>
#define N 3

void fillMAtrix(int arr[N][N])
{
    int i = 0, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            printf("Enter [%d][%d]: ", i, j);
            scanf("%d", &arr[i][j]);
        }
    }
}

void displayMtrix(int arr[N][N])
{
    printf("Matrix[R][C]\n");
    int i = 0, j;
    for (i = 0; i < N; i++)
    {
        for (j = 0; j < N; j++)
        {
            printf("%d\t", arr[i][j]);
        }
        printf("\n\n");
    }
}

bool isDiagonalMatrix(int mat[N][N])
{
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)

            // condition to check other elements
            // except main diagonal are zero or not.
            if ((i != j) && (mat[i][j] != 0))
                return false;
    return true;
}

bool isScalarMatrix(int mat[N][N])
{
    // Check all elements except main diagonal are
    // zero or not.
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            if ((i != j) && (mat[i][j] != 0))
                return false;

    // Check all diagonal elements are same or not.
    for (int i = 0; i < N - 1; i++)
        if (mat[i][i] != mat[i + 1][i + 1])
            return false;
    return true;
}

bool isUpperTriangularMatrix(int mat[N][N])
{
    for (int i = 1; i < N; i++)
        for (int j = 0; j < i; j++)
            if (mat[i][j] != 0)
                return false;
    return true;
}

bool check_lower_triangular_matrix(int mat[N][N])
{
    int i, j;
    for (i = 0; i < N; i++)
        for (j = i + 1; j < N; j++)
            if (mat[i][j] != 0)
                return false;
    return true;
}

void transpose(int arr[N][N], int brr[N][N]) //Function Definition
{
    for (int i = 0; i < N; i++) //Transpose Matrix initialization
    {
        for (int j = 0; j < N; j++)
        {
            brr[j][i] = arr[i][j]; //Store elements in the transpose matrix
        }
    }
    printf("\nAfter transpose the elements are...\n");
    for (int i = 0; i < N; i++) //Print the transpose matrix
    {
        for (int j = 0; j < N; j++)
        {
            printf("%d\t", brr[i][j]);
        }
        printf("\n\n");
    }
}

int main()
{
    /* 2D array declaration*/
    int disp[N][N];

    /*Counter variables for the loop*/

    fillMAtrix(disp);
    displayMtrix(disp);
    if (isDiagonalMatrix(disp))
    {
        printf("Matrix is Diagonal \n");
    }
    else
    {
        printf("Matix is not Diagonal\n");
    }
    if (isUpperTriangularMatrix(disp))
    {
        printf("Matrix is Upper Triangular Matix\n");
    }
    else
    {
        printf("Matrix is Not Upper Triangular Matix\n");
    }
    if (check_lower_triangular_matrix(disp))
    {
        printf("Matrix is Lower Triangular Matix\n");
    }
    else
    {
        printf("Matrix is Not Lower Triangular Matix\n");
    }
    if (isScalarMatrix(disp))
    {
        printf("Matrix is Scalar \n");
    }
    else
    {
        printf("Matix is not Scalar\n");
    }
    int tran[N][N];
    transpose(disp, tran);

    return 0;
}