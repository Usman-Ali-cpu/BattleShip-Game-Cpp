package edu.psu.ist311;

public class Lab {

}
