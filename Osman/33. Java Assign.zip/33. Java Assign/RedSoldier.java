public class RedSoldier extends Soldier {
    public void hunt() {
        System.out.println("Killed using hand");
        System.out.println("Game Over");
    }

}
