public abstract class Soldier {
    int x;
    int y;

    Soldier() {
        x = 0;
        y = 0;
    }

    public abstract void hunt();

}
