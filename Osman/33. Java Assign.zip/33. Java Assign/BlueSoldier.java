public class BlueSoldier extends Soldier {
    public void hunt() {
        System.out.println("Killed using gun");
        System.out.println("Game Over");
    }

}
