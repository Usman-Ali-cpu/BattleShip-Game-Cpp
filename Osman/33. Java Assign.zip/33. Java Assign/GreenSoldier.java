public class GreenSoldier extends Soldier {

    @Override
    public void hunt() {
        // TODO Auto-generated method stub
        System.out.println("Killed using knife");
        System.out.println("Game Over");

    }

}
