public class Question1c {

    public static void main(String[] args) {
        /*
         * String _1Name; // it is valid variable name String _$1Name; // it is valid
         * variable name String 1Name; // it is not valid variable name String _Name1;
         * // it is valid variable name String Name1-; // it is not valid variable name
         */

        // (d)

        // (e)
        /*
         * != is for non-equality operator. < is less than operator. > is greater than
         * operator. <= is less than or equal to operator. > = is greater than or equal
         * to operator.
         * 
         */

    }

}
