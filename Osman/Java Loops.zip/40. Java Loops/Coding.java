public class Coding {

    public static void main(String[] args) {
        // Given a string, return true if the first instance of "x" in the string is
        // immediately followed by another "x".
        System.out.println("******** DoubleX ********");
        System.out.println(doubleX("axxbb"));
        System.out.println(doubleX("axaxax"));
        System.out.println(doubleX("xxxxx"));
        System.out.println("********** ******  *********\n");

        // Given a string, return a version where all the "x" have been removed. Except
        // an "x" at the very start or end should not be removed.
        System.out.println("********* StringX  ***********");
        System.out.println(stringX("xxHxix"));
        System.out.println(stringX("abxxxcd"));
        System.out.println(stringX("xabxxxcdx"));
        System.out.println("********** *******  *********\n");

        // Suppose the string "yak" is unlucky. Given a string, return a version where
        // all the "yak" are removed, but the "a" can be any char. The "yak" strings
        // will not overlap.
        System.out.println("*********  StringYak  *********");
        System.out.println(stringYak("Yakpak"));
        System.out.println(stringYak("pakyak"));
        System.out.println(stringYak("yak123ya"));
        System.out.println("**********  ********  *********\n");

        // Given 2 strings, a and b, return the number of the positions where they
        // contain the same length 2 substring. So "xxcaazz" and "xxbaaz" yields 3,
        // since the "xx", "aa", and "az" substrings appear in the same place in both
        // strings
        System.out.println("*********  StringMatch  **********");
        System.out.println(stringMatch("xxcaazz", "xxbaaz"));
        System.out.println(stringMatch("abc", "abc"));
        System.out.println(stringMatch("abc", "axc"));
        System.out.println("********** *********  *********\n");

        // count the number of "xx" in the given string. We'll say that overlapping is
        // allowed, so "xxx" contains 2 "xx".
        System.out.println("**********  CountXX  ************");
        System.out.println(countXX("abcxx"));
        System.out.println(countXX("xxx"));
        System.out.println(countXX("xxxx"));
        System.out.println("********* *********  *********\n");

        // Given a string, return a string made of the chars at indexes 0,1, 4,5, 8,9
        // ... so "kittens" yields "kien".
        System.out.println("**********  AltPairs  **********");
        System.out.println(altPairs("kitten"));
        System.out.println(altPairs("Chocolate"));
        System.out.println(altPairs("CodingHorror"));
        System.out.println("********** *********  *********");

    }

    public static boolean doubleX(String s) {
        for (int i = 0; i < s.length() - 1; i++) {
            if (s.charAt(i) == 'x' && s.charAt(i + 1) == 'x') {
                return true;
            }
        }
        return false;
    }

    public static String stringX(String s) {
        String x = "";
        x += s.charAt(0);
        for (int i = 1; i < s.length() - 1; i++) {
            if (s.charAt(i) != 'x') {
                x += s.charAt(i);
            }
        }
        x += s.charAt(s.length() - 1);
        return x;
    }

    public static String stringYak(String s) {
        String x = "";
        String y = "";
        for (int i = 0; i < s.length() - 2; i++) {
            x = s.substring(i, i + 3);
            if (x.equals("Yak") || x.equals("YAK") || x.equals("yak")) {
                y = s.substring(0, i);
                y += s.substring(i + 3, s.length());
            }
        }
        return y;
    }

    public static int stringMatch(String x, String y) {
        int length = x.length();
        if (y.length() < length) {
            length = y.length();
        }
        int count = 0;
        for (int i = 0; i < length - 1; i++) {
            if (x.subSequence(i, i + 2).toString().equals(y.subSequence(i, i + 2).toString())) {
                count++;
            }
        }
        return count;

    }

    public static int countXX(String x) {
        int count = 0;
        for (int i = 0; i < x.length() - 1; i++) {
            if (x.subSequence(i, i + 2).toString().equals("xx")) {
                count++;
            }
        }
        return count;
    }

    public static String altPairs(String s) {
        String x = "";
        for (int i = 0; i < s.length() - 1; i += 4) {
            x += s.substring(i, i + 2);
        }
        if (s.length() % 2 == 1) {
            x += s.charAt(s.length() - 1);
        }
        return x;

    }

}