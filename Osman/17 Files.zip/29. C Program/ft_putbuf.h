#ifndef FT_PUTBUF_H // check if file is not define
#define FT_PUTBUF_H // from above if file or function does not define, define that file / function

void ft_putbuf(char c); // prototype of function, passing character as an argument
void ft_resetbuf(void); // function prototype, function reset the char array,

#endif // end if from top 2 lines