#ifndef RUSH00_H // to check if file is not already define
#define RUSH00_H // if not define then define rush00.h

#include "rush00.h"

void rush(int y, int x); // prototype/header for printing rush
void ft_putchar(char c); // prototype of function which prints char
#endif