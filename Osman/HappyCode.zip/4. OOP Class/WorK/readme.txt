Here is your delivery.
You can see all code is neat and well running. The code in files you send was not good. There were
a lot of mistakes.
I see your concepts are weak. We have to work on these concepts. 
We have done almost all tasks except 5 because that one is lengthy, you have to add more amount for this,