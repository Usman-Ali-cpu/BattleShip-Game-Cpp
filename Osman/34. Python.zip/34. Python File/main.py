packfile = open("confPack.txt", "r")  # open file to read
packlines = []  # declare list to store pack names
for li in packfile:  # loop thorugh lines reas by files
    packlines.append(li)  # add to list of packs


basic = packlines[0]  # first pack is basic
bonus = packlines[1]  # second pack is bonus


file = open("employees.txt", "r")  # open employee file to read

for line in file:  # loop through lines read from file, one by one
    # separate out each word in a line by comma, and store as list
    elements = line.split(",")
    length = len(elements)  # get length of list, how many words are there
    # check if length is 3 and last word is Y
    if(length == 3 and elements[length-1][0] == 'Y'):
        print("Name: " + elements[0] + " " + elements[1])  # print name
        print("Pack Type: " + basic)  # print pack type
    # check if length is 4 and second last and last word is Y
    elif(length == 4 and elements[length-1][0] == 'Y' and elements[length-2] == "Y"):
        print("Name: " + elements[0] + " " + elements[1])  # print name
        print("Pack Type: " + basic[:-1] + " + " +
              bonus + "\n")  # print pack type
    # check if length is 4 and second last is blank and last word is Y
    elif(length == 4 and elements[length-1][0] == 'Y' and elements[length-2] == ""):
        print("Name: " + elements[0] + " " + elements[1])  # print name
        print("Pack Type: " + basic[:-1] + "\n")  # print pack type
    else:
        print("Name: " + elements[0] + " " + elements[1][:-1])  # print name
        print("Not Attending\n")
