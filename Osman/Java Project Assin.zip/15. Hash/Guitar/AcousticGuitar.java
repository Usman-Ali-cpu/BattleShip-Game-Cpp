public class AcousticGuitar extends Guitar {

    public AcousticGuitar() {
        size = "undefined";
        color = "undefined";

    }

    public void woodsyStrum() {
        System.out.println("I am woddy Strum");
    }

    @Override
    String getType() {
        // TODO Auto-generated method stub
        return null;
    }

}
