from random_Art import makeImage
from flask import Flask, render_template,  request
import os


app = Flask(__name__)
picfolder = os.path.join('static', 'images')
app.config['UPLOAD_FOLDER'] = picfolder


@app.route('/')
@app.route('/home')
def home():
    return render_template('index.html')


@app.route('/result', methods=['POST', "GET"])
def result():
    output = makeImage(20)
    pic1 = os.path.join(app.config['UPLOAD_FOLDER'], output)
    return render_template("index.html", img_produce=pic1)


if __name__ == '__main__':
    app.run(debug=True, port=5001)
