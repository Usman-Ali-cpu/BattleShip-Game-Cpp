#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void removeDuplicates(vector<int> &v) // function header taking vector pass by reference
{
    auto end = v.end();                     // take the end of vector in end
    for (auto i = v.begin(); i != end; ++i) // loop through vector while the 'i' is not equal to ends
    {
        end = remove(i + 1, end, *i); // remove function which return then end of vector, end will be updated
    }

    v.erase(end, v.end()); // remove that part of vector
}

int main()
{
    vector<int> v = {};
    cout << "Enter values to vector : \n";
    int input;
    while ((cin >> input))
    {
        if (!isdigit(input))
        {
            v.push_back(input);
        }
        else
        {
            break;
        }
    }
    cout << "Before Removing Duplicates: ";
    for (int i = 0; i < v.size(); i++)
    {
        cout << v.at(i) << " ";
    }

    removeDuplicates(v);
    cout << "\nAfter Removing Duplicates: ";
    for (int i = 0; i < v.size(); i++)
    {
        cout << v.at(i) << " ";
    }

    return 0;
}
