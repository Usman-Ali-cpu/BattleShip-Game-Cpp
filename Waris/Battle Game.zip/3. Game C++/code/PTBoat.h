
#pragma once
#ifndef PTBoat_H
#define PTBoat_H

#include <iostream>
#include "Ship.h"
using namespace std;
class PTBoat: public Ship{
public:
    PTBoat();
    ~PTBoat();
    void fireWeapons();

};
#endif