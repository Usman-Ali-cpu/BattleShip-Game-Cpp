#include <iostream>
// #include "Ship.h"
#include "Submarine.h"
using namespace std;

// it prints appropiate message when weapon is fired
void Submarine::fireWeapons(){
    cout<< "Bearing, set, match: Firing torpedos!"<< endl;
}
// constructor will be called when Battle ship's object is make 
Submarine::Submarine(){
    setHullpoints(3);
    setName("Submarine");
    setPlaced(false);
}
// before destroying object this destructor is called
Submarine::~Submarine(){
    setHullpoints(-1);
    setName(" ");
    setPlaced(false);
}

