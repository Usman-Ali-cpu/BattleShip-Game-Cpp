
#ifndef Player_H
#define Player_H

#include <iostream>
#include "Ship.cpp"
#include "BattleShip.cpp"
#include "Carrier.cpp"
#include "Destroyer.cpp"
#include "PTBoat.cpp"
#include "Submarine.cpp"

using namespace std;
class Player{
private:
    string name;
    int score;
    int ships;
    char enemy[10][10];
    char fleet[10][10];
    bool tacNuke;
    Ship * battleship = new Battleship();
    Ship * carriership = new Carrier();
    Ship * destroyership = new Destroyer();
    Ship * submarineship = new Submarine();
    Ship * ptboatship = new PTBoat();
public:
    Player(string a_name);
    ~Player();
    void shipMutator();
    string getname();
    char * getfleet();
    char * getEnemy();
    char getfleetAt(int i, int j);
    char getEnemyAt(int i, int j);
    void printBoard(char board[10][10]);
    int getScore();
    bool checkEmpty(int size, int x, int y, char direction);
    bool validPlacement(char ship, int x, int y, char direction);
    void markShip(char ship, int x, int y, char direction);

    int converLetterToInt(char letter);
    bool checkDuplication(char c);
    void placeShips();
    bool validShot(int x, int y);
    void markResult(int x, int y, Player &p);
    void fire(Player& p);
    bool checkIfWon();
    void detonate(int x, int y, Player& p);
    bool checkNuke(int x, int y);
};
#endif
