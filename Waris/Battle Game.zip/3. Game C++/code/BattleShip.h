
#pragma once
#ifndef BATTLESHIP_H
#define BATTLESHIP_H

#include <iostream>
#include "Ship.h"
using namespace std;
class Battleship: public Ship{
public:
    Battleship();
    ~Battleship();
    void fireWeapons();

};
#endif