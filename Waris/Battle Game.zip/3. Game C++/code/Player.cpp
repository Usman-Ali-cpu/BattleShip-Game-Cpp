#include <iostream>
#include "Player.h"
using namespace std;

// Parameterized Constructor for name
// • Sets name to the passed parameter
    Player::Player(string a_name){
        name = a_name;
        score = 0;
        for(int i=0; i< 10; i++){
            for(int j=0; j< 10; j++){
                enemy[i][j] = ' ';
                fleet[i][j] = ' ';
            }
        }
        tacNuke = true;
        ships = 0;
    }
    // Desturctor is called while destroying object
    Player::~Player(){
        name = " ";
        score = -1;
        for(int i=0; i< 10; i++){
            for(int j=0; j< 10; j++){
                enemy[i][j] = ' ';
                fleet[i][j] = ' ';
            }
        }
        tacNuke = false;
        ships = 1;
    }
    // Decrements player’s ship field by 1 each time called
    void Player::shipMutator(){
        ships--;
    }
    // return name of current player
    string Player::getname(){
        return name;
    }
    // return 2D array of fleet of player 
    char * Player::getfleet(){
        return reinterpret_cast<char *>(fleet);
    }
    // return 2D array of enemy of player 
    char * Player::getEnemy(){
        return reinterpret_cast<char *>(enemy);
    }
    // return a char at specific position of fleet of player 
    char Player::getfleetAt(int i, int j){
        return fleet[i][j];
    }
    // return a char at specific position of enemy of player 
    char Player::getEnemyAt(int i, int j){
        return enemy[i][j];
    }
    // Prints out the passed board 
    //  player name and score above the board
    // print player’s ship status and its current hull point value
    void Player::printBoard(char board[10][10]){
        cout<< "\nPlayer Name : "<< name<< endl;
        cout<< name <<" Player Score : "<< score<< endl;
        cout<< "Ship : "<< ships << endl;
        cout<< "   A   B   C   D   E   F   G   H   I   J"<< endl;
        for(int i=0; i< 10; i++){
            cout<< i<< " ";
            for(int j=0; j< 10; j++){
                cout<<  board[i][j] << " | ";
            }
            cout<< "\n-----------------------------------------"<< endl;
        }
        cout<< name <<" Ship Status -> \t";
        cout << "CV="<< carriership->getHullpoints() << "  BB=" << battleship->getHullpoints()<< "  DD="<< destroyership->getHullpoints()<< endl;
        cout << "\t\t\t SUB="<< submarineship->getHullpoints() << "      PT=" << ptboatship->getHullpoints()<<endl;
    }
    // return score of current player 
    int Player::getScore(){
        return score;
    }
    // Checks if a specified set of positions is empty in the fleet array
    // Uses the direction and size of the ship to determine, starting from location specified by x, y
    // Returns true if all elements needed are empty
    // Otherwise false
    bool Player::checkEmpty(int size, int x, int y, char direction){
        if(direction == 'h'){
            // for(int i=x; i< size; i++){
                for(int j=y; j<size; j++){
                    if(fleet[x][j] != ' '){
                        return false;
                    }
                }
            // }
            return true;
        }
        else {
            for(int i=x; i< size; i++){
                // for(int j=y; j<size; j++){
                    if(fleet[i][y] != ' '){
                        return false;
                    }
                // }
            }
            return true;
        }
    }
    // Based on ship, will check that the requested placement of 
    // it in the fleet array is valid for position x,y and ship direction
    bool Player::validPlacement(char ship, int x, int y, char direction){
        int size =0;
        
        if(x< 10 && y< 10){
            if(ship == 'S'){
                size = 3;
            }
            else if(ship == 'C'){
                size = 5;
            }
            else if(ship == 'D'){
                size = 3;
            }
            else if(ship == 'B'){
                size = 4;
            }
            else if(ship == 'P'){
                size = 2;
            }
            if(!checkEmpty(size, x, y, direction)){
                return false;
            }
            else {
                return true;
            }
        }
        return false;
    }
    // 
    // Marks the specified elements of the fleet array starting from the specified 
    // position by x,y and following the direction specified
    void Player::markShip(char ship, int x, int y, char direction){
            int size = 0;
            if(ship == 'S'){
                size = 3;
                if(direction == 'h'){
                    for(int j=y; j<size+y; j++){
                        fleet[x][j] = 'S';
                    }
                }
                else if(direction == 'v'){
                    for(int j=x; j<size+x; j++){
                        fleet[j][y] = 'S';
                    }
                }
            }
            else if(ship == 'C'){
                size = 5;
                if(direction == 'h'){
                    for(int j=y; j<size+y; j++){
                        cout<< "Place "<<endl;
                        fleet[x][j] = 'C';
                    }
                }
                else if(direction == 'v'){
                    for(int j=x; j<size+x; j++){
                        fleet[j][y] = 'C';
                    }
                }
            }
            else if(ship == 'D'){
                size = 3;
                if(direction == 'h'){
                    for(int j=y; j<size+y; j++){
                        fleet[x][j] = 'D';
                    }
                }
                else if(direction == 'v'){
                    for(int j=x; j<size+x; j++){
                        fleet[j][y] = 'D';
                    }
                }
            }
            else if(ship == 'B'){
                size = 4;
                if(direction == 'h'){
                    for(int j=y; j<size+y; j++){
                        fleet[x][j] = 'B';
                    }
                }
                else if(direction == 'v'){
                    for(int j=x; j<size+x; j++){
                        fleet[j][y] = 'B';
                    }
                }
            }
            else if(ship == 'P'){
                size = 2;
                if(direction == 'h'){
                    for(int j=y; j<size+y; j++){
                        fleet[x][j] = 'P';
                    }
                }
                else if(direction == 'v'){
                    for(int j=x; j<size+x; j++){
                        fleet[j][y] = 'P';
                    }
                }
            }
        printBoard(fleet);
    }

    // Converts the user enter letter for the column selection in to an integer
    int Player::converLetterToInt(char letter){
        if(letter >= 48 && letter <58){
            int num = letter-48;
            return num;
        }
        return -1;
    }
    // return true if any duplicate is found in fleet 
    bool Player::checkDuplication(char c){
        for(int i=0; i< 10; i++){
            for(int j=0; j< 10; j++){
                if(fleet[i][j] == c){
                    return true;
                }
            }
        }
        return false;
    }
    // 
    //  Prompts the user to ask which ship would they like to place next. 
    //  Checks if the player already placed selected ship 
    //  If already placed re-prompt user for a different ship 
    //  Marks the ship’s field true after successful placement o Increments player’s ships field
    void Player::placeShips(){
        cout<< "C. Carrier Ship "<< endl;
        cout<< "B. Battle Ship " << endl;
        cout<< "D. Destroyer Ship " << endl;
        cout<< "S. Submarine Ship " << endl;
        cout<< "P. PTBoat Ship " << endl;
        char choice;
        cout<< "Enter your choice : ";
        cin>> choice;
        while(checkDuplication(choice)){
            cout<< "Duplicated found "<< endl;
            cout<< "C. Carrier Ship "<< endl;
            cout<< "B. Battle Ship " << endl;
            cout<< "D. Destroyer Ship " << endl;
            cout<< "S. Submarine Ship " << endl;
            cout<< "P. PTBoat Ship " << endl;
            cout<< "Enter your choice ";
            cin>> choice;
        }
        cout<< "Enter row : ";
        int row;
        cin>> row;
        cout<< "Enter column : ";
        int col;
        cin>> col;
        cout<< "Enter direction : (h or v): ";
        char dir;
        cin>> dir;
        if(validPlacement(choice, row, col, dir)){
            cout<< "Vlaid "<< endl;
            this->ships++;
            markShip(choice, row,col,dir);
        }
        switch (choice)
        {
        case 'C':
            carriership->setPlaced(true);
            break;
        case 'B':
            battleship->setPlaced(true);
            break;
        case 'D':
            destroyership->setPlaced(true);
            break;
        case 'S':
            submarineship->setPlaced(true);
            break;
        case 'P':
            ptboatship->setPlaced(true);
            break;
        default:
            break;
        }
        cout<< "Ship placed and ships number incremented successfully "<<endl;
    }
    // the enemy array element at that position is empty
    // if empty return ture
    // else return false
    bool Player::validShot(int x, int y){
        if(x > 9 || y > 9){
            return false;
        }
        else {
            if(enemy[x][y] == ' '){
                return true;
            }
            else {
                return false;
            }
        }
    }
    // 
    // Place an ‘X’ in the current player’s enemy array at the position specified by x,y
    // If missed set the current player’s enemy array at position x,y to ‘O’
    void Player::markResult(int x, int y, Player &p){
                if(p.fleet[x][y] == 'S' || p.fleet[x][y] == 'C' || p.fleet[x][y] == 'B' || p.fleet[x][y] == 'D' || p.fleet[x][y] == 'P'){
                    enemy[x][y] = 'X';
                    cout<< "Hit! " << endl;
                    p.shipMutator();
                    score += 10;
                    if(p.fleet[x][y] == 'S'){
                        p.submarineship->hit();
                        if(p.submarineship->getHullpoints()<= 0){
                            cout<< "Enemy "<< p.submarineship->getName()<< " Sunk!"<< endl;
                        }
                    }
                    else if(p.fleet[x][y] == 'C'){
                        p.carriership->hit();
                        if(p.carriership->getHullpoints()<= 0){
                            cout<< "Enemy "<< p.carriership->getName()<< " Sunk!"<< endl;
                        }
                    }
                    else if(p.fleet[x][y] == 'B'){
                        p.battleship->hit();
                        if(p.battleship->getHullpoints()<= 0){
                            cout<< "Enemy "<< p.battleship->getName()<< " Sunk!"<< endl;
                        }
                    }
                    else if(p.fleet[x][y] == 'D'){
                        p.destroyership->hit();
                        if(p.destroyership->getHullpoints()<= 0){
                            cout<< "Enemy "<< p.destroyership->getName()<< " Sunk!"<< endl;
                        }
                    }
                    else if (p.fleet[x][y] == 'P'){
                        p.ptboatship->hit();
                        if(p.ptboatship->getHullpoints()<= 0){
                            cout<< "Enemy "<< p.ptboatship->getName()<< " Sunk!"<< endl;
                        }
                    }
                }

                else{
                    enemy[x][y] = 'O';
                    cout<< "Miss" << endl;
                }
    }
    // If Yes, ask the user to input shot coordinates for the center of the blast. if Y the do blast
    // Allows the current player to shot a number of times equal to their current ship total.
    // Ships should display their fireWeapons message based 
    // on the order indicated by the client above every turn they shoot.
    void Player::fire(Player& p){
        cout<< "You want to fire First thing to do : (Y/N) : ";
        char c;
        cin >> c;
        if(c == 'Y' || c == 'y'){
            cout<< "Enter coordinates for center of blast " << endl;
            cout<< "Enter x coordinate : ";
            int x ;
            cin >> x;
            cout<< "Enter y coordinate : ";
            int y;
            cin>> y;
            if(checkNuke(x, y)){
                cout<< "Check Nuke "<< endl;
                if(p.tacNuke == true && p.ships > 3 && p.submarineship->getHullpoints() > 0 || p.carriership->getHullpoints() > 3){
                        detonate(x, y, p);
                        cout<< "Detonated " << endl;
                        p.tacNuke = false;
                }
            }
        }
        else{
            cout<< "Stating nuke is on standby "<< endl;
        }

        if(submarineship->getHullpoints()> 0){
            cout<< "Enter Location to shoot in player "<< endl;
            cout<< "Enter row : ";
            int r;
            cin>> r;
            cout<< "Enter col: ";
            int co;
            cin>> co;
            char direct;
            cout<< "Enter direction horizontal or verticle (h or v) : ";
            cin>> direct;

            if(validPlacement('S', r,co, direct)){
                markResult(r, co, p);
            }
        }
        if(carriership->getHullpoints()> 0){
            cout<< "Enter Location to shoot in player "<< endl;
            cout<< "Enter row : ";
            int r;
            cin>> r;
            cout<< "Enter col: ";
            int co;
            cin>> co;
            char direct;
            cout<< "Enter direction horizontal or verticle (h or v) : ";
            cin>> direct;

            if(validPlacement('C', r,co, direct)){
                markResult(r, co, p);
            }
        }
        if(destroyership->getHullpoints()> 0){
            cout<< "Enter Location to shoot in player "<< endl;
            cout<< "Enter row : ";
            int r;
            cin>> r;
            cout<< "Enter col: ";
            int co;
            cin>> co;
            char direct;
            cout<< "Enter direction horizontal or verticle (h or v) : ";
            cin>> direct;

            if(validPlacement('D', r,co, direct)){
                markResult(r, co, p);
            }
        }
        if(ptboatship->getHullpoints()> 0){
            cout<< "Enter Location to shoot in player "<< endl;
            cout<< "Enter row : ";
            int r;
            cin>> r;
            cout<< "Enter col: ";
            int co;
            cin>> co;
            char direct;
            cout<< "Enter direction horizontal or verticle (h or v) : ";
            cin>> direct;

            if(validPlacement('P', r,co, direct)){
                markResult(r, co, p);
            }
        }
        if(battleship->getHullpoints()> 0){
            cout<< "Enter Location to shoot in player "<< endl;
            cout<< "Enter row : ";
            int r;
            cin>> r;
            cout<< "Enter col: ";
            int co;
            cin>> co;
            char direct;
            cout<< "Enter direction horizontal or verticle (h or v) : ";
            cin>> direct;

            if(validPlacement('B', r,co, direct)){
                markResult(r, co, p);
            }
        }

        
    }
    // if the current plyer’s score is equal to 170 print a message saying
    // o “~~~Player playerName is Victorious!~~~”
    bool Player::checkIfWon(){
        if(score >= 170){
            cout<< "~~~Player " << this->name <<" is Victorious!~~~"<< endl;
            cout<< "Score : " << score<< endl;
            return true;
        }
        return false;
    }
    // 
    //  Checks each of the 11 blast locations based on the user input x and y coordinates in the pattern seen above. 
    //  Call the markResult method only if the current player’s enemy board is unmarked at that location.
    void Player::detonate(int x, int y, Player& p){
        if(enemy[x-1][y-1]=' '){
            markResult(x, y, p);
        }
        if(enemy[x-2][y-2]=' '){
            markResult(x, y, p);
        }
        if(enemy[x+1][y+1]=' '){
            markResult(x, y, p);
        }
        if(enemy[x+2][y+2]=' '){
            markResult(x, y, p);
        }
        if(enemy[x-2][y]=' '){
            markResult(x, y, p);
        }
        if(enemy[x+2][y]=' '){
            markResult(x, y, p);
        }
        if(enemy[x-1][y+1]=' '){
            markResult(x, y, p);
        }
        if(enemy[x-2][y+2]=' '){
            markResult(x, y, p);
        }
        if(enemy[x+1][y-1]=' '){
            markResult(x, y, p);
        }
        if(enemy[x+2][y-2]=' '){
            markResult(x, y, p);
        }
        if(enemy[x][y]=' '){
            markResult(x, y, p);
        }
    }
    // Checks that all positions of the blast are within the confines of the playing board.
    bool Player::checkNuke(int x, int y){
        if(x-2 >= 0 && x+2 <= 9 && y-2 >= 0 && y+2 <= 9){
            return true;
        }
        return false;
    }
