#include <iostream>
#include "BattleShip.h"
using namespace std;

// it prints appropiate message when weapon is fired
void Battleship::fireWeapons(){
    cout<< "Firing 16inches guns! This is gonna be loud!"<< endl;
}
// constructor will be called when Battle ship's object is make 
Battleship::Battleship(){
    setHullpoints(4);
    setName("Battleship");
    setPlaced(false);
}

// before destroying object this destructor is called
Battleship::~Battleship(){
    setHullpoints(-1);
    setName(" ");
    setPlaced(false);
}
