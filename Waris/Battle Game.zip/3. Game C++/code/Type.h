// Will be discussed in the pointer lecture
#include <iostream>
#include "Player.h"
using namespace std;

    typedef Player::shipMutator(){
        ships--;
    }
    typedef Player::getname(){
        return name;
    }
    typedef * Player::getfleet(){
        return reinterpret_cast<char *>(fleet);
    }