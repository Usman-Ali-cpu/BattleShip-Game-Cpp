#pragma once
#ifndef DESTROYER_H
#define DESTROYER_H


#include <iostream>
#include "Ship.h"
using namespace std;

class Destroyer: public Ship{
public:
    Destroyer();
    ~Destroyer();
    void fireWeapons();

};
#endif