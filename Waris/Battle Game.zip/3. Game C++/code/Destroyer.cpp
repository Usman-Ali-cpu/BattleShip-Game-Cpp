#include <iostream>
// #include "Ship.h"
#include "Destroyer.h"
using namespace std;

// it prints appropiate message when weapon is fired
void Destroyer::fireWeapons(){
    cout<< "Launching depthcharges! Boom goes the dynamite!"<< endl;
}
// constructor will be called when Destroyer ship's object is make 
Destroyer::Destroyer(){
    setHullpoints(3);
    setName("Destroyer");
    setPlaced(false);
}
// before destroying object this destructor is called
Destroyer::~Destroyer(){
    setHullpoints(-1);
    setName(" ");
    setPlaced(false);
}

