#pragma once
#ifndef SUBMARINE_H
#define SUBMARINE_H


#include <iostream>
#include "Ship.h"
using namespace std;


class Submarine: public Ship{
public:
    Submarine();
    ~Submarine();
    void fireWeapons();

};
#endif