#include <iostream>
// #include "Ship.h"
#include "PTBoat.h"
using namespace std;

// it prints appropiate message when weapon is fired

void PTBoat::fireWeapons(){
    cout<< "Full Speed Ahead! Firing torpedos!"<< endl;
}
// constructor will be called when Battle ship's object is make 
PTBoat::PTBoat(){
    setHullpoints(2);
    setName("PTBoat");
    setPlaced(false);
}
// before destroying object this destructor is called
PTBoat::~PTBoat(){
    setHullpoints(-1);
    setName(" ");
    setPlaced(false);
}


