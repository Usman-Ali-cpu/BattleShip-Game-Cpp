
#pragma once
#ifndef SHIP_H
#define SHIP_H
#include <iostream>
using namespace std;


class Ship{
private:
    string name;
    int hullpoints;
    bool placed;
public:
    Ship();
    ~Ship();

    void setName(string n);
    void setHullpoints(int point);
    void setPlaced(bool p);

    string getName();
    int getHullpoints();
    bool getPlaced();

    void hit();
    void fireWeapons(){ }

};
#endif