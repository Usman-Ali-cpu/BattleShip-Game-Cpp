
#pragma once
#ifndef CARRIER_H
#define CARRIER_H

#include <iostream>
#include "Ship.h"
using namespace std;

class Carrier: public Ship{
public:
    Carrier();
    ~Carrier();
    void fireWeapons();
};
#endif