#include <iostream>
#include "Carrier.h"
using namespace std;

// it prints appropiate message when weapon is fired
void Carrier::fireWeapons(){
    cout<< "Luanching planes for airstrike!"<< endl;

}
// constructor will be called when Carrier ship's object is make 
Carrier::Carrier(){
    setHullpoints(5);
    setName("Carrier");
    setPlaced(false);
}
// before destroying object this destructor is called
Carrier::~Carrier(){
    setHullpoints(-1);
    setName(" ");
    setPlaced(false);
}