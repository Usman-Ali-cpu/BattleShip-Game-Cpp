public class Animal {
    String eyeColor;
    int weight;
    int age;

    public Animal(String eyeColor, int weight, int age) {
        this.eyeColor = eyeColor;
        this.weight = weight;
        this.age = age;
    }

    public double calculateFoodCost() {
        return 0.0;
    };

    public boolean isLoin() {
        return false;
    }

}
