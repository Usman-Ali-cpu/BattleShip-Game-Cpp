Here i'm delivering work. You would get two cpp files. One is Array based spliting and other file is list based spliting. 
The requirments you send to me include ItemType class, i implement that class and more at very start there is class sortType 
i implement that class and functions in side it that also include splitlist. for split it it is required to write neccessary functions
i also implement those function. Thanks a lot. I am here to help you again. 