def increasingfactors(number):  # function header
    factors = []
    # looping through each number from one to +1 of given number
    for num in range(1, number + 1):
        if number % num == 0:  # number is factor, reminder of given number with looping number is 0
            factors.append(num)  # add number in the list
    return factors


number = int(input("Enter a number : "))
# calling function to get factors in increasing order
increFactor = increasingfactors(number)
for factor in increFactor:
    print(str(factor) + " is factor of " + str(number))  # printing all factors
