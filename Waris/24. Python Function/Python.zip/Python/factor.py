number = int(input("Enter a number : "))
# calling function to get factors in increasing order
numbers = []
for num in range(1, number + 1):
    numbers.append(num)
# looping through each number from one to +1 of given number
for n in numbers:
    if number % n == 0:  # number is factor, reminder of given number with looping number is 0
        print(n)  # add number in the list
