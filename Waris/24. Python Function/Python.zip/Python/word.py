def frequencyofwords(word, wordlist):
    return wordList.count(word)  # return count of word in that list


# input string and store as list by spliting
wordList = input("Enter a String : ").split(' ')
wordstemp = []  # declaring array
for word in wordList:  # traversing all words of list
    wordstemp.append(word)  # append word in temp list
    count = frequencyofwords(word, wordList)  # find frequency of word in list
    if wordstemp.count(word) == 1:  # to check it is already printed
        print(word + " = ", count)
