import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter First Name : ");
        String name1 = in.nextLine();
        System.out.print("Enter Second Name : ");
        String name2 = in.nextLine();
        QuizCalculator student1 = new QuizCalculator(name1);
        QuizCalculator student2 = new QuizCalculator(name2);
        student1.addScore(70);
        student1.addScore(85);
        student1.addScore(90);

        student2.addScore(65);
        student2.addScore(75);
        student2.addScore(80);
        System.out.println(student1.toString());
        System.out.println(student2.toString());
        in.close();

    }

}
