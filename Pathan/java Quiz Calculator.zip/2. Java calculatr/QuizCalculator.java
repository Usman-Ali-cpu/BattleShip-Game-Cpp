public class QuizCalculator {
    String studentName;
    int totalQuiz;
    double sumScoreQuiz;

    public QuizCalculator(String name) {
        studentName = name;
        totalQuiz = 0;
        sumScoreQuiz = 0;
    }

    public void addScore(double score) {
        sumScoreQuiz += score;
        totalQuiz++;
    }

    public double getAverage() {
        return sumScoreQuiz / totalQuiz;
    }

    @Override
    public String toString() {
        return studentName + " quiz average: " + String.format("%6.2f", getAverage());
    }

}