interface ICanValidate {

    boolean isValid();
}
